PROYECTO CARNET VIRTUAL - MODIFICADO

Funciones agregadas:
1. Pantalla de Login
   Usuario: admin
   Contraseña: admin123
2. Pantalla visual "Mi Carnet"
3. Registro local de ENTRADA y SALIDA
4. Historial persistente en el dispositivo
5. Botones de Nuevo carnet y Buscar en la pantalla principal

Notas:
- Los carnets continúan consumiendo la API/AWS original del proyecto.
- El login y el historial funcionan localmente con SharedPreferences.
- Para producción, el login debería migrarse a Amazon Cognito y el historial a DynamoDB/API Gateway.
- La compilación automática no pudo ejecutarse en este entorno porque Gradle 9.4.1 necesita descargarse desde internet. Abre el proyecto en Android Studio, sincroniza Gradle y ejecuta normalmente.
