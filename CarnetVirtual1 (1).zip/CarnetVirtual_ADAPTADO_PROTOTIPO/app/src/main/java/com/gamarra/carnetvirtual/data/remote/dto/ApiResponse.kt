package com.gamarra.carnetvirtual.data.remote.dto

data class ApiResponse(
    val success: Boolean,
    val data: CarnetsDataDto
)