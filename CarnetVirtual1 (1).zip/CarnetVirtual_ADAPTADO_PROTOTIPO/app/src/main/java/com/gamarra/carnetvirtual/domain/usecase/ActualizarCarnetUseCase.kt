package com.gamarra.carnetvirtual.domain.usecase

import com.gamarra.carnetvirtual.domain.model.Carnet
import com.gamarra.carnetvirtual.domain.repository.CarnetRepository

class ActualizarCarnetUseCase(private val repository: CarnetRepository) {

    suspend operator fun invoke(carnet: Carnet) {
        repository.actualizarCarnet(carnet)
    }

}