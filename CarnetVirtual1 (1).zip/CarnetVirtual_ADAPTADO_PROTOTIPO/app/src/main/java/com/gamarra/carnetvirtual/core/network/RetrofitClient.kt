package com.gamarra.carnetvirtual.core.network

import com.gamarra.carnetvirtual.core.utils.Constantes
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object RetrofitClient {

    private fun createRetrofit(baseUrl: String): Retrofit {
        return Retrofit.Builder()
            .baseUrl(baseUrl)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    val carnetApi: ApiService by lazy {
        createRetrofit(Constantes.BASE_URL_CARNETS).create(ApiService::class.java)
    }

    val authApi: AuthApiService by lazy {
        createRetrofit(Constantes.BASE_URL_LOGIN).create(AuthApiService::class.java)
    }

}