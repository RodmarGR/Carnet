package com.gamarra.carnetvirtual.domain.repository

import com.gamarra.carnetvirtual.domain.model.Carnet

interface CarnetRepository {

    suspend fun getCarnets(): List<Carnet>

    suspend fun login(correo: String, clave: String): Carnet

    suspend fun insertarCarnet(carnet: Carnet)

    suspend fun getCarnetById(id: String): Carnet

    suspend fun actualizarCarnet(carnet: Carnet)

    suspend fun eliminarCarnet(id: String)

}