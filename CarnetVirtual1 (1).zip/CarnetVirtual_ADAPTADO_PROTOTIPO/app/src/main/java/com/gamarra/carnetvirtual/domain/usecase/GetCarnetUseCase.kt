package com.gamarra.carnetvirtual.domain.usecase

import com.gamarra.carnetvirtual.domain.model.Carnet
import com.gamarra.carnetvirtual.domain.repository.CarnetRepository

class GetCarnetUseCase(private val repository: CarnetRepository) {

    suspend operator fun invoke(id: String): Carnet {
        return repository.getCarnetById(id)
    }

}