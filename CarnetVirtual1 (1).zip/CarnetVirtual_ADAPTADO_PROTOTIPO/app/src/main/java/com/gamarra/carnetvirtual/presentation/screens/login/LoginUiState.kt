package com.gamarra.carnetvirtual.presentation.screens.login

import com.gamarra.carnetvirtual.domain.model.Carnet

data class LoginUiState(
    val isLoading: Boolean = false,
    val user: Carnet? = null,
    val error: String? = null,
    val loginSuccess: Boolean = false
)