package com.gamarra.carnetvirtual

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.navigation.compose.rememberNavController
import com.gamarra.carnetvirtual.data.local.AccessHistoryRepository
import com.gamarra.carnetvirtual.data.local.SessionManager
import com.gamarra.carnetvirtual.presentation.components.AppScaffold
import com.gamarra.carnetvirtual.presentation.navigation.AppNavigation
import com.gamarra.carnetvirtual.ui.theme.CarnetVirtualTheme

class MainActivity : ComponentActivity() {
    private val container by lazy { (application as CarnetApplication).container }
    private val sessionManager by lazy { SessionManager(this) }
    private val accessRepository by lazy { AccessHistoryRepository(this) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CarnetVirtualTheme {
                val navHostController = rememberNavController()
                AppScaffold(navHostController, sessionManager) { paddingValues ->
                    AppNavigation(navHostController, container, paddingValues, sessionManager, accessRepository)
                }
            }
        }
    }
}
