package com.gamarra.carnetvirtual.di

import com.gamarra.carnetvirtual.data.remote.datasource.RemoteDataSource
import com.gamarra.carnetvirtual.data.repository.CarnetRepositoryImpl
import com.gamarra.carnetvirtual.domain.repository.CarnetRepository

class RepositoryModule(networkModule: NetworkModule) {

    private val remoteDataSource by lazy {
        RemoteDataSource(
            carnetApi = networkModule.carnetApiService,
            authApi = networkModule.authApiService
        )
    }

    val carnetRepository: CarnetRepository by lazy {
        CarnetRepositoryImpl(remoteDataSource)
    }
}