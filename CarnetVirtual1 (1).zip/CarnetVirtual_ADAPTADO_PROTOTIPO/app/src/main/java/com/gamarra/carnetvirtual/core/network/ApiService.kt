package com.gamarra.carnetvirtual.core.network

import com.gamarra.carnetvirtual.data.remote.dto.ApiResponse
import com.gamarra.carnetvirtual.data.remote.dto.CarnetDetalleResponse
import com.gamarra.carnetvirtual.data.remote.dto.InsertarCarnetRequest
import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.DELETE
import retrofit2.http.GET
import retrofit2.http.POST
import retrofit2.http.PUT
import retrofit2.http.Path

interface ApiService {

    @GET("carnets")
    suspend fun getCarnets(): Response<ApiResponse>

    @POST("carnets")
    suspend fun insertarCarnet(
        @Body request: InsertarCarnetRequest
    ): Response<CarnetDetalleResponse>

    @GET("carnets/{id}")
    suspend fun getCarnetById(
        @Path("id") id: String
    ): Response<CarnetDetalleResponse>

    @PUT("carnets/{id}")
    suspend fun actualizarCarnet(
        @Path("id") id: String,
        @Body request: InsertarCarnetRequest
    ): Response<CarnetDetalleResponse>

    @DELETE("carnets/{id}")
    suspend fun eliminarCarnet(
        @Path("id") id: String
    ): Response<Unit>
}