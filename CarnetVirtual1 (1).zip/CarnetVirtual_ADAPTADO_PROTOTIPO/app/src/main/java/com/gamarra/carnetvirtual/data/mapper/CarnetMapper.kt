package com.gamarra.carnetvirtual.data.mapper

import com.gamarra.carnetvirtual.data.remote.dto.CarnetDto
import com.gamarra.carnetvirtual.data.remote.dto.InsertarCarnetRequest
import com.gamarra.carnetvirtual.domain.model.Carnet

object CarnetMapper {

    fun toDomain(carnetDto: CarnetDto): Carnet {
        // Combinamos apellidos si viene ap_materno
        val apellidosCompletos = buildString {
            append(carnetDto.apellidos ?: "")
            if (!carnetDto.apellidoMaterno.isNullOrBlank()) {
                if (this.isNotEmpty()) append(" ")
                append(carnetDto.apellidoMaterno)
            }
        }.trim()

        return Carnet(
            id = carnetDto.id ?: "",
            codigo = carnetDto.codigo ?: "",
            dni = carnetDto.dni ?: "",
            nombres = carnetDto.nombres ?: "",
            apellidos = if (apellidosCompletos.isEmpty()) carnetDto.apellidos ?: "" else apellidosCompletos,
            cargo = carnetDto.cargo ?: "",
            empresa = carnetDto.empresa ?: "",
            sede = carnetDto.sede ?: "",
            fechaVencimiento = carnetDto.fechaVencimiento ?: "",
            estado = carnetDto.estado ?: ""
        )
    }

    fun toInsertCarnetRequest(carnet: Carnet): InsertarCarnetRequest =
        InsertarCarnetRequest(
            id = carnet.id,
            codigo = carnet.codigo,
            dni = carnet.dni,
            nombres = carnet.nombres,
            apellidos = carnet.apellidos,
            cargo = carnet.cargo,
            empresa = carnet.empresa,
            sede = carnet.sede,
            fechaVencimiento = carnet.fechaVencimiento,
            estado = carnet.estado
        )
}