package com.gamarra.carnetvirtual.di

import com.gamarra.carnetvirtual.presentation.viewmodel.AgregarViewModel
import com.gamarra.carnetvirtual.presentation.viewmodel.EditarViewModel
import com.gamarra.carnetvirtual.presentation.viewmodel.InicioViewModel
import com.gamarra.carnetvirtual.presentation.viewmodel.LoginViewModel

class AppContainer {

    private val networkModule = NetworkModule()

    private val repositoryModule = RepositoryModule(networkModule)

    private val useCaseModule = UseCaseModule(repositoryModule)

    val loginViewModel by lazy {
        LoginViewModel(useCaseModule.carnetUseCases)
    }

    val inicioViewModel by lazy {
        InicioViewModel(useCaseModule.carnetUseCases)
    }

    val agregarViewModel by lazy {
        AgregarViewModel(useCaseModule.carnetUseCases)
    }

    val editarViewModel by lazy {
        EditarViewModel(useCaseModule.carnetUseCases)
    }
}