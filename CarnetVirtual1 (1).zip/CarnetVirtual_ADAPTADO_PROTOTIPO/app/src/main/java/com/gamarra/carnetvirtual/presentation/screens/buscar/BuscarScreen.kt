package com.gamarra.carnetvirtual.presentation.screens.buscar

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.SearchBar
import androidx.compose.material3.SearchBarDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.gamarra.carnetvirtual.di.AppContainer
import com.gamarra.carnetvirtual.presentation.components.EmptyScreen
import com.gamarra.carnetvirtual.presentation.components.LoadingScreen

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BuscarScreen(
    container: AppContainer
) {
    val viewModel = container.inicioViewModel
    val uiState by viewModel.uiState.collectAsState()

    if (uiState.isLoading) {
        LoadingScreen()
    } else {
        Column {
            SearchBar(
                inputField = {
                    SearchBarDefaults.InputField(
                        query = uiState.search,
                        onQueryChange = viewModel::onSearchChange,
                        onSearch = {},
                        expanded = false,
                        onExpandedChange = {},
                        placeholder = {
                            Text("Buscar colaborador")
                        }
                    )
                },
                expanded = false,
                onExpandedChange = {},
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(12.dp)
            ) {}

            if (uiState.listaCarnetsFiltro.isEmpty()) {
                EmptyScreen(
                    mensaje = if (uiState.search.isBlank()) {
                        "Escribe el nombre, DNI o código del colaborador"
                    } else {
                        "No existen carnets con los datos buscados"
                    }
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize()
                ) {
                    items(
                        items = uiState.listaCarnetsFiltro,
                        key = { carnet -> carnet.id }
                    ) { carnet ->
                        CarnetItemBuscar(
                            carnet = carnet
                        )
                    }
                }
            }
        }
    }
}