package com.gamarra.carnetvirtual.presentation.navigation

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.gamarra.carnetvirtual.data.local.AccessHistoryRepository
import com.gamarra.carnetvirtual.data.local.SessionManager
import com.gamarra.carnetvirtual.di.AppContainer
import com.gamarra.carnetvirtual.presentation.screens.agregar.AgregarScreen
import com.gamarra.carnetvirtual.presentation.screens.buscar.BuscarScreen
import com.gamarra.carnetvirtual.presentation.screens.confirmacion.ConfirmacionScreen
import com.gamarra.carnetvirtual.presentation.screens.editar.EditarScreen
import com.gamarra.carnetvirtual.presentation.screens.historial.HistorialScreen
import com.gamarra.carnetvirtual.presentation.screens.inicio.InicioScreen
import com.gamarra.carnetvirtual.presentation.screens.login.LoginScreen
import com.gamarra.carnetvirtual.presentation.screens.micarnet.MiCarnetScreen
import com.gamarra.carnetvirtual.presentation.screens.perfil.PerfilScreen
import com.gamarra.carnetvirtual.presentation.screens.registro.RegistroScreen

@Composable
fun AppNavigation(
    navHostController: NavHostController,
    container: AppContainer,
    paddingValues: PaddingValues,
    sessionManager: SessionManager,
    accessRepository: AccessHistoryRepository
) {
    NavHost(
        navController = navHostController,
        startDestination = NavRutas.LOGIN,
        modifier = Modifier.padding(paddingValues)
    ) {

        composable(NavRutas.LOGIN) {
            LoginScreen(
                navHostController,
                sessionManager,
                container
            )
        }

        composable(NavRutas.INICIO) {
            InicioScreen(
                container,
                navHostController
            )
        }

        composable(NavRutas.AGREGAR) {
            AgregarScreen(
                container,
                navHostController
            )
        }

        composable(NavRutas.BUSCAR) {
            BuscarScreen(
                container
            )
        }

        composable(NavRutas.MI_CARNET) {
            MiCarnetScreen(
                container
            )
        }

        composable(NavRutas.REGISTRO) {
            RegistroScreen(
                accessRepository,
                navHostController,
                sessionManager,
                container
            )
        }

        composable(NavRutas.HISTORIAL) {
            HistorialScreen(
                accessRepository
            )
        }

        composable(NavRutas.PERFIL) {
            PerfilScreen(
                navHostController,
                sessionManager
            )
        }

        composable(
            "${NavRutas.CONFIRMACION}/{tipo}/{fecha}/{hora}"
        ) { entry ->

            val tipo = entry.arguments
                ?.getString("tipo")
                ?: "REGISTRO"

            val fecha = entry.arguments
                ?.getString("fecha")
                ?: "-"

            val hora = entry.arguments
                ?.getString("hora")
                ?: "-"

            ConfirmacionScreen(
                navHostController,
                tipo,
                fecha,
                hora
            )
        }

        composable(
            "${NavRutas.EDITAR}/{id}"
        ) { entry ->

            val id = entry.arguments
                ?.getString("id")
                ?: ""

            EditarScreen(
                container,
                navHostController,
                id
            )
        }
    }
}