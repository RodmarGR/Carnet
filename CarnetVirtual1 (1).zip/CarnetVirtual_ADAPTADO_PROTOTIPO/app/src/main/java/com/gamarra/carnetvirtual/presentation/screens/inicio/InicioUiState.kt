package com.gamarra.carnetvirtual.presentation.screens.inicio

import com.gamarra.carnetvirtual.domain.model.Carnet

data class InicioUiState(
    val isLoading: Boolean = false,
    val listaCarnets: List<Carnet> = emptyList(),
    val listaCarnetsFiltro: List<Carnet> = emptyList(),
    val search: String = "",
    val isDelete: Boolean = false,
    val error: String? = null
)