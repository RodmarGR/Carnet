package com.gamarra.carnetvirtual.domain.usecase

import com.gamarra.carnetvirtual.domain.repository.CarnetRepository

class EliminarCarnetUseCase(private val repository: CarnetRepository) {

    suspend operator fun invoke(id: String) {
        repository.eliminarCarnet(id)
    }

}