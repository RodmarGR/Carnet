package com.gamarra.carnetvirtual.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.gamarra.carnetvirtual.domain.usecase.CarnetUseCases
import com.gamarra.carnetvirtual.presentation.event.EventBus
import com.gamarra.carnetvirtual.presentation.event.UiEvent
import com.gamarra.carnetvirtual.presentation.screens.login.LoginUiState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class LoginViewModel(
    private val useCases: CarnetUseCases
) : ViewModel() {

    private val _uiState = MutableStateFlow(LoginUiState())
    val uiState = _uiState.asStateFlow()

    fun login(correo: String, clave: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true, error = null)
            try {
                val carnet = useCases.login(correo, clave)
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    user = carnet,
                    loginSuccess = true
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = e.message
                )
                EventBus.send(UiEvent.Error(e.message ?: "Error al iniciar sesión"))
            }
        }
    }
}