package com.gamarra.carnetvirtual.data.remote.datasource

import com.gamarra.carnetvirtual.core.network.ApiService
import com.gamarra.carnetvirtual.core.network.AuthApiService
import com.gamarra.carnetvirtual.data.remote.dto.ApiResponse
import com.gamarra.carnetvirtual.data.remote.dto.CarnetDto
import com.gamarra.carnetvirtual.data.remote.dto.InsertarCarnetRequest
import com.gamarra.carnetvirtual.data.remote.dto.LoginResponse

class RemoteDataSource(
    private val carnetApi: ApiService,
    private val authApi: AuthApiService
) {

    suspend fun login(correo: String, clave: String): LoginResponse? {
        val response = authApi.login(correo, clave)
        if (!response.isSuccessful) {
            throw Exception("Error al iniciar sesión: ${response.errorBody()?.string()}")
        }
        return response.body()
    }

    suspend fun getCarnets(): ApiResponse? {
        val response = carnetApi.getCarnets()

        if (!response.isSuccessful) {
            throw Exception("Error al listar carnets: ${response.errorBody()?.string()}")
        }

        return response.body()
    }

    suspend fun insertarCarnet(
        request: InsertarCarnetRequest
    ): CarnetDto? {
        val response = carnetApi.insertarCarnet(request)

        if (!response.isSuccessful) {
            throw Exception("Error al registrar: ${response.errorBody()?.string()}")
        }

        return response.body()?.data
    }

    suspend fun getCarnetById(id: String): CarnetDto? {
        val response = carnetApi.getCarnetById(id)

        if (!response.isSuccessful) {
            throw Exception("Carnet no encontrado")
        }

        return response.body()?.data
    }

    suspend fun actualizarCarnet(
        id: String,
        request: InsertarCarnetRequest
    ): CarnetDto? {
        val response = carnetApi.actualizarCarnet(id, request)

        if (!response.isSuccessful) {
            throw Exception("Error al actualizar: ${response.errorBody()?.string()}")
        }

        return response.body()?.data
    }

    suspend fun eliminarCarnet(id: String) {
        val response = carnetApi.eliminarCarnet(id)

        if (!response.isSuccessful) {
            throw Exception("Error al eliminar carnet")
        }
    }
}