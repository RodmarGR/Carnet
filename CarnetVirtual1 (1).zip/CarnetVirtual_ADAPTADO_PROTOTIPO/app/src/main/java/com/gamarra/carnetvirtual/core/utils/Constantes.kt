package com.gamarra.carnetvirtual.core.utils

object Constantes {
    const val BASE_URL_LOGIN = "https://t69qea2xml.execute-api.us-east-1.amazonaws.com/"
    const val BASE_URL_CARNETS = "https://2uen6f77qd.execute-api.us-east-1.amazonaws.com/"
}