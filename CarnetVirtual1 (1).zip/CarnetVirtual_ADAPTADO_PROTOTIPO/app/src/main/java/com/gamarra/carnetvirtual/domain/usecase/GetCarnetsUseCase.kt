package com.gamarra.carnetvirtual.domain.usecase

import com.gamarra.carnetvirtual.domain.repository.CarnetRepository

class GetCarnetsUseCase(private val repository: CarnetRepository) {

    suspend operator fun invoke() = repository.getCarnets()

}