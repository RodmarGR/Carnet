package com.gamarra.carnetvirtual.presentation.components

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

@Composable
fun FormCarnet(
    codigo: String,
    dni: String,
    nombres: String,
    apellidos: String,
    cargo: String,
    empresa: String,
    sede: String,
    fechaVencimiento: String,
    estado: String,
    onCodigoChange: (String) -> Unit,
    onDniChange: (String) -> Unit,
    onNombresChange: (String) -> Unit,
    onApellidosChange: (String) -> Unit,
    onCargoChange: (String) -> Unit,
    onEmpresaChange: (String) -> Unit,
    onSedeChange: (String) -> Unit,
    onFechaVencimientoChange: (String) -> Unit,
    onEstadoChange: (String) -> Unit
) {
    Row(
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        OutlinedTextField(
            value = codigo,
            onValueChange = onCodigoChange,
            label = { Text("Código") },
            modifier = Modifier.weight(1f)
        )

        OutlinedTextField(
            value = dni,
            onValueChange = onDniChange,
            label = { Text("DNI") },
            modifier = Modifier.weight(1f)
        )
    }

    OutlinedTextField(
        value = nombres,
        onValueChange = onNombresChange,
        label = { Text("Nombres") },
        modifier = Modifier.fillMaxWidth()
    )

    OutlinedTextField(
        value = apellidos,
        onValueChange = onApellidosChange,
        label = { Text("Apellidos") },
        modifier = Modifier.fillMaxWidth()
    )

    OutlinedTextField(
        value = cargo,
        onValueChange = onCargoChange,
        label = { Text("Cargo") },
        modifier = Modifier.fillMaxWidth()
    )

    OutlinedTextField(
        value = empresa,
        onValueChange = onEmpresaChange,
        label = { Text("Empresa cliente") },
        modifier = Modifier.fillMaxWidth()
    )

    OutlinedTextField(
        value = sede,
        onValueChange = onSedeChange,
        label = { Text("Sede") },
        modifier = Modifier.fillMaxWidth()
    )

    OutlinedTextField(
        value = fechaVencimiento,
        onValueChange = onFechaVencimientoChange,
        label = { Text("Fecha de vencimiento") },
        placeholder = { Text("Ejemplo: 2026-12-31") },
        modifier = Modifier.fillMaxWidth()
    )

    val estaActivo = estado.equals("Activo", ignoreCase = true)

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = if (estaActivo) {
                "Carnet activo"
            } else {
                "Carnet inactivo"
            }
        )

        Switch(
            checked = estaActivo,
            onCheckedChange = { marcado ->
                onEstadoChange(
                    if (marcado) "Activo" else "Inactivo"
                )
            }
        )
    }
}