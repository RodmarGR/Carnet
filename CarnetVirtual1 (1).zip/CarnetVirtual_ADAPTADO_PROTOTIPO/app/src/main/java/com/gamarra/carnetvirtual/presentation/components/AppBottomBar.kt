package com.gamarra.carnetvirtual.presentation.components

import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.gamarra.carnetvirtual.presentation.navigation.BotonNavItem

@Composable
fun AppBottomBar(
    navHostController: NavHostController
) {

    val opciones = listOf(
        BotonNavItem.Inicio,
        BotonNavItem.MiCarnet,
        BotonNavItem.Registro,
        BotonNavItem.Historial
    )

    val rutaSeleccionada = navHostController
        .currentBackStackEntryAsState()
        .value
        ?.destination
        ?.route

    NavigationBar(
        containerColor = Color(0xFF595959)
    ) {

        opciones.forEach { item ->

            NavigationBarItem(
                selected = rutaSeleccionada == item.ruta,

                onClick = {
                    if (rutaSeleccionada != item.ruta) {
                        navHostController.navigate(item.ruta) {
                            launchSingleTop = true
                        }
                    }
                },

                icon = {
                    Icon(
                        imageVector = item.icono,
                        contentDescription = item.titulo
                    )
                },

                label = {
                    Text(
                        text = item.titulo
                    )
                },

                colors = NavigationBarItemDefaults.colors(
                    selectedIconColor = Color.White,
                    selectedTextColor = Color.White,
                    indicatorColor = Color(0xFFE91E63),
                    unselectedIconColor = Color(0xFFE7E7E7),
                    unselectedTextColor = Color(0xFFE7E7E7)
                )
            )
        }
    }
}