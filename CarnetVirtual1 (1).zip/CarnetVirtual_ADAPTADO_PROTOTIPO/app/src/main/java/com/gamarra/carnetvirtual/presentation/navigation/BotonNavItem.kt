package com.gamarra.carnetvirtual.presentation.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.ui.graphics.vector.ImageVector

sealed class BotonNavItem(val ruta: String, val titulo: String, val icono: ImageVector) {
    data object Inicio : BotonNavItem(NavRutas.INICIO, "Inicio", Icons.Default.Home)
    data object MiCarnet : BotonNavItem(NavRutas.MI_CARNET, "Carnet", Icons.Default.Badge)
    data object Registro : BotonNavItem(NavRutas.REGISTRO, "Registro", Icons.Default.SwapHoriz)
    data object Historial : BotonNavItem(NavRutas.HISTORIAL, "Historial", Icons.Default.History)
}
