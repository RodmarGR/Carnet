package com.gamarra.carnetvirtual.presentation.screens.registro

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ElevatedCard
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.gamarra.carnetvirtual.data.local.AccessHistoryRepository
import com.gamarra.carnetvirtual.data.local.SessionManager
import com.gamarra.carnetvirtual.di.AppContainer
import com.gamarra.carnetvirtual.presentation.navigation.NavRutas
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun RegistroScreen(
    repository: AccessHistoryRepository,
    navController: NavHostController,
    sessionManager: SessionManager,
    container: AppContainer
) {
    var now by remember {
        mutableStateOf(Date())
    }

    val state by container.inicioViewModel.uiState.collectAsState()

    val idCarnetUsuario = sessionManager.obtenerCarnetId()
    val nombreSesion = sessionManager.obtenerNombreUsuario()

    val carnetUsuario = state.listaCarnets.firstOrNull { carnet ->
        carnet.id == idCarnetUsuario && carnet.id.isNotBlank()
    }

    // Lógica para el nombre mostrado (Nombre + Apellido Paterno)
    val nombreMostrado = remember(carnetUsuario, nombreSesion) {
        if (carnetUsuario != null) {
            val primerApellido = carnetUsuario.apellidos.split(" ").firstOrNull() ?: ""
            "${carnetUsuario.nombres} $primerApellido".trim()
        } else if (nombreSesion.isNotBlank()) {
            val parts = nombreSesion.split(" ")
            if (parts.size >= 2) "${parts[0]} ${parts[1]}" else nombreSesion
        } else {
            "Usuario"
        }
    }

    // Lógica para encontrar la foto (nombre_apellido)
    val nombreParaFoto = remember(nombreMostrado) {
        if (nombreMostrado != "Usuario") {
            nombreMostrado.replace(" ", "_").lowercase()
        } else ""
    }

    val cargo = if (carnetUsuario != null) carnetUsuario.cargo else sessionManager.obtenerCargoUsuario()
    val dni = if (carnetUsuario != null) carnetUsuario.dni else sessionManager.obtenerDniUsuario()

    val fechaTexto = SimpleDateFormat(
        "dd-MM-yyyy",
        Locale("es", "PE")
    ).format(now)

    val horaTexto = SimpleDateFormat(
        "HH:mm",
        Locale.getDefault()
    ).format(now)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(20.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        UsuarioCard(
            nombre = nombreMostrado,
            cargo = cargo.ifBlank { "Usuario" },
            dni = dni.ifBlank { "-" },
            nombreParaFoto = nombreParaFoto
        )

        Spacer(
            modifier = Modifier.height(18.dp)
        )

        Text(
            text = "Selecciona el tipo de registro",
            style = MaterialTheme.typography.titleLarge,
            fontWeight = FontWeight.Bold
        )

        Spacer(
            modifier = Modifier.height(20.dp)
        )

        AccessCard(
            titulo = "ENTRADA",
            subtitulo = "Registrar entrada",
            entrada = true
        ) {
            val registro = repository.register("ENTRADA")

            now = Date()

            navController.navigate(
                "${NavRutas.CONFIRMACION}/ENTRADA/" +
                        "${registro.fecha.replace('/', '-')}/" +
                        registro.hora
            )
        }

        Spacer(
            modifier = Modifier.height(14.dp)
        )

        AccessCard(
            titulo = "SALIDA",
            subtitulo = "Registrar salida",
            entrada = false
        ) {
            val registro = repository.register("SALIDA")

            now = Date()

            navController.navigate(
                "${NavRutas.CONFIRMACION}/SALIDA/" +
                        "${registro.fecha.replace('/', '-')}/" +
                        registro.hora
            )
        }

        Spacer(
            modifier = Modifier.height(22.dp)
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(
                containerColor = MaterialTheme.colorScheme.surfaceVariant
            )
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = "Sede actual",
                    style = MaterialTheme.typography.labelLarge
                )

                Text(
                    text = "Principal",
                    fontWeight = FontWeight.Bold
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(
                        text = "Fecha: $fechaTexto"
                    )

                    Text(
                        text = "Hora: $horaTexto"
                    )
                }
            }
        }
    }
}

@Composable
private fun UsuarioCard(
    nombre: String,
    cargo: String,
    dni: String,
    nombreParaFoto: String
) {
    val context = LocalContext.current
    val imageRes = remember(nombreParaFoto) {
        if (nombreParaFoto.isNotBlank()) {
            val id = context.resources.getIdentifier(nombreParaFoto, "drawable", context.packageName)
            if (id != 0) id else 0
        } else 0
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        elevation = CardDefaults.cardElevation(
            defaultElevation = 4.dp
        ),
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surface
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (imageRes != 0) {
                Image(
                    painter = painterResource(id = imageRes),
                    contentDescription = "Usuario",
                    modifier = Modifier
                        .size(58.dp)
                        .clip(CircleShape),
                    contentScale = ContentScale.Crop
                )
            } else {
                Icon(
                    imageVector = Icons.Default.AccountCircle,
                    contentDescription = "Usuario",
                    modifier = Modifier.size(58.dp),
                    tint = MaterialTheme.colorScheme.primary
                )
            }

            Spacer(
                modifier = Modifier.width(14.dp)
            )

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = nombre,
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = cargo,
                    style = MaterialTheme.typography.bodyMedium
                )

                Text(
                    text = "DNI: $dni",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            if (imageRes != 0) {
                Image(
                    painter = painterResource(id = imageRes),
                    contentDescription = "Foto esquina",
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape),
                    contentScale = ContentScale.Crop
                )
            }
        }
    }
}

@Composable
private fun AccessCard(
    titulo: String,
    subtitulo: String,
    entrada: Boolean,
    onClick: () -> Unit
) {
    val colorAccion = if (entrada) {
        Color(0xFF2E9D4D)
    } else {
        Color(0xFFD94841)
    }

    ElevatedCard(
        onClick = onClick,
        modifier = Modifier
            .fillMaxWidth()
            .height(110.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxSize()
                .padding(18.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Icon(
                imageVector = if (entrada) {
                    Icons.Default.Login
                } else {
                    Icons.Default.Logout
                },
                contentDescription = titulo,
                modifier = Modifier.size(52.dp),
                tint = colorAccion
            )

            Spacer(
                modifier = Modifier.width(18.dp)
            )

            Column {
                Text(
                    text = titulo,
                    style = MaterialTheme.typography.titleLarge,
                    fontWeight = FontWeight.Bold
                )

                Text(
                    text = subtitulo
                )
            }
        }
    }
}