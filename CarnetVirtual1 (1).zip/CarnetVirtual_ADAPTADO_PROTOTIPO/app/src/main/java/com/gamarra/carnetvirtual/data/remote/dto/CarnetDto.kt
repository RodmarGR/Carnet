package com.gamarra.carnetvirtual.data.remote.dto

import com.google.gson.annotations.SerializedName

data class CarnetDto(
    val id: String? = null,
    val codigo: String? = null,
    val dni: String? = null,
    
    // Nombres: soporta "nombres" (API carnets) y "nombre" (API usuarios)
    @SerializedName("nombres", alternate = ["nombre"])
    val nombres: String? = null,
    
    // Apellidos: soporta "apellidos" (API carnets) y "ap_paterno" (API usuarios)
    @SerializedName("apellidos", alternate = ["ap_paterno"])
    val apellidos: String? = null,
    
    // Apellido Materno (opcional para el nombre completo)
    @SerializedName("ap_materno")
    val apellidoMaterno: String? = null,
    
    // Cargo: soporta "cargo" (API carnets) y "rol" (API usuarios)
    @SerializedName("cargo", alternate = ["rol"])
    val cargo: String? = null,
    
    val empresa: String? = null,
    val sede: String? = null,
    val fechaVencimiento: String? = null,
    val estado: String? = null,
    
    @SerializedName("email")
    val email: String? = null
)