package com.gamarra.carnetvirtual.di

import com.gamarra.carnetvirtual.core.network.ApiService
import com.gamarra.carnetvirtual.core.network.AuthApiService
import com.gamarra.carnetvirtual.core.network.RetrofitClient

class NetworkModule {

    val carnetApiService: ApiService by lazy {
        RetrofitClient.carnetApi
    }

    val authApiService: AuthApiService by lazy {
        RetrofitClient.authApi
    }
}