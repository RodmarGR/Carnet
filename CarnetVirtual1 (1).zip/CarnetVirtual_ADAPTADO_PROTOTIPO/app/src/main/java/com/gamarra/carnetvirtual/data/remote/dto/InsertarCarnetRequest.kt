package com.gamarra.carnetvirtual.data.remote.dto

data class InsertarCarnetRequest(
    val id: String,
    val codigo: String,
    val dni: String,
    val nombres: String,
    val apellidos: String,
    val cargo: String,
    val empresa: String,
    val sede: String,
    val fechaVencimiento: String,
    val estado: String
)