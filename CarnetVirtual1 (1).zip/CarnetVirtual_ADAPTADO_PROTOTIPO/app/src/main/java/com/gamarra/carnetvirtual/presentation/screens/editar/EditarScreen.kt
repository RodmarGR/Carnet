package com.gamarra.carnetvirtual.presentation.screens.editar

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.gamarra.carnetvirtual.di.AppContainer
import com.gamarra.carnetvirtual.presentation.components.FormCarnet
import com.gamarra.carnetvirtual.presentation.components.LoadingScreen

@Composable
fun EditarScreen(
    container: AppContainer,
    navHostController: NavHostController,
    id: String
) {
    val viewModel = container.editarViewModel
    val uiState by viewModel.uiState.collectAsState()

    LaunchedEffect(id) {
        viewModel.buscarCarnet(id)
    }

    LaunchedEffect(uiState.isSuccess) {
        if (uiState.isSuccess) {
            container.inicioViewModel.cargarCarnets()
            viewModel.clearSuccess()
            navHostController.popBackStack()
        }
    }

    if (uiState.isLoading && uiState.id.isEmpty()) {
        LoadingScreen()
    } else {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
                .verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            FormCarnet(
                codigo = uiState.codigo,
                dni = uiState.dni,
                nombres = uiState.nombres,
                apellidos = uiState.apellidos,
                cargo = uiState.cargo,
                empresa = uiState.empresa,
                sede = uiState.sede,
                fechaVencimiento = uiState.fechaVencimiento,
                estado = uiState.estado,
                onCodigoChange = viewModel::onCodigoChange,
                onDniChange = viewModel::onDniChange,
                onNombresChange = viewModel::onNombresChange,
                onApellidosChange = viewModel::onApellidosChange,
                onCargoChange = viewModel::onCargoChange,
                onEmpresaChange = viewModel::onEmpresaChange,
                onSedeChange = viewModel::onSedeChange,
                onFechaVencimientoChange = viewModel::onFechaVencimientoChange,
                onEstadoChange = viewModel::onEstadoChange
            )

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                modifier = Modifier.fillMaxWidth(),
                enabled = !uiState.isLoading,
                onClick = {
                    viewModel.actualizarCarnet()
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFE91E63),
                    contentColor = Color.White
                )
            ) {
                if (uiState.isLoading) {
                    CircularProgressIndicator()
                } else {
                    Icon(
                        imageVector = Icons.Default.Save,
                        contentDescription = "Actualizar carnet"
                    )

                    Spacer(modifier = Modifier.width(8.dp))

                    Text("Actualizar Carnet")
                }
            }
        }
    }
}