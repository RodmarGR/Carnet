package com.gamarra.carnetvirtual.domain.usecase

import com.gamarra.carnetvirtual.domain.model.Carnet
import com.gamarra.carnetvirtual.domain.repository.CarnetRepository

class LoginUseCase(
    private val repository: CarnetRepository
) {
    suspend operator fun invoke(correo: String, clave: String): Carnet {
        return repository.login(correo, clave)
    }
}