package com.gamarra.carnetvirtual.data.remote.dto

data class CarnetDetalleResponse(
    val success: Boolean,
    val data: CarnetDto
)