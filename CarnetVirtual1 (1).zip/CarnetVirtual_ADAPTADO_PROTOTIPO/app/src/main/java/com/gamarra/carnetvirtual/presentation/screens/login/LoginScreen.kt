package com.gamarra.carnetvirtual.presentation.screens.login

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Badge
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.gamarra.carnetvirtual.data.local.SessionManager
import com.gamarra.carnetvirtual.di.AppContainer
import com.gamarra.carnetvirtual.presentation.navigation.NavRutas

@Composable
fun LoginScreen(
    navController: NavHostController,
    sessionManager: SessionManager,
    container: AppContainer
) {
    var correo by remember {
        mutableStateOf("")
    }

    var clave by remember {
        mutableStateOf("")
    }

    var errorLocal by remember {
        mutableStateOf<String?>(null)
    }

    val state by container.loginViewModel.uiState.collectAsState()

    LaunchedEffect(state.loginSuccess) {
        if (state.loginSuccess && state.user != null) {
            val user = state.user!!
            sessionManager.guardarDatosUsuario(
                idCarnet = user.id,
                nombreCompleto = "${user.nombres} ${user.apellidos}".trim(),
                cargo = user.cargo.ifBlank { "Usuario" },
                codigo = user.codigo,
                dni = user.dni.ifBlank { "00000000" }
            )
            navController.navigate(NavRutas.INICIO) {
                popUpTo(NavRutas.LOGIN) {
                    inclusive = true
                }
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .padding(28.dp),
        contentAlignment = Alignment.Center
    ) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            elevation = CardDefaults.cardElevation(
                defaultElevation = 8.dp
            )
        ) {
            Column(
                modifier = Modifier.padding(28.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Badge,
                    contentDescription = null,
                    modifier = Modifier.size(72.dp),
                    tint = Color(0xFFE91E63)
                )

                Spacer(
                    modifier = Modifier.height(12.dp)
                )

                Text(
                    text = "Carnet Virtual",
                    style = MaterialTheme.typography.headlineMedium
                )

                Text(
                    text = "Inicia sesión con tu correo"
                )

                Spacer(
                    modifier = Modifier.height(28.dp)
                )

                OutlinedTextField(
                    value = correo,
                    onValueChange = {
                        correo = it
                        errorLocal = null
                    },
                    label = {
                        Text("Correo electrónico")
                    },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(
                    modifier = Modifier.height(12.dp)
                )

                OutlinedTextField(
                    value = clave,
                    onValueChange = {
                        clave = it
                        errorLocal = null
                    },
                    label = {
                        Text("Contraseña")
                    },
                    singleLine = true,
                    visualTransformation = PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth()
                )

                val displayError = errorLocal ?: state.error
                displayError?.let {
                    Text(
                        text = it,
                        color = MaterialTheme.colorScheme.error,
                        modifier = Modifier.padding(top = 8.dp)
                    )
                }

                Spacer(
                    modifier = Modifier.height(20.dp)
                )

                if (state.isLoading) {
                    CircularProgressIndicator()
                } else {
                    Button(
                        onClick = {
                            if (correo.isBlank() || clave.isBlank()) {
                                errorLocal = "Completa todos los campos"
                            } else {
                                container.loginViewModel.login(correo.trim(), clave.trim())
                            }
                        },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text("INICIAR SESIÓN")
                    }
                }
            }
        }
    }
}