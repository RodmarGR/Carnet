package com.gamarra.carnetvirtual.presentation.screens.historial

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.gamarra.carnetvirtual.data.local.AccessHistoryRepository

@Composable
fun HistorialScreen(repository: AccessHistoryRepository) {
    var records by remember { mutableStateOf(repository.getAll()) }
    var confirmClear by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
            Text("Registros: ${records.size}", style = MaterialTheme.typography.titleMedium)
            TextButton(onClick = { confirmClear = true }, enabled = records.isNotEmpty()) { Text("Limpiar") }
        }
        if (records.isEmpty()) Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { Text("Aún no hay entradas ni salidas registradas") }
        else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(records, key = { it.id }) { record ->
                Card(Modifier.fillMaxWidth()) {
                    ListItem(
                        headlineContent = { Text(record.tipo) },
                        supportingContent = { Text("${record.fecha} · ${record.hora}") },
                        leadingContent = { Icon(if (record.tipo == "ENTRADA") Icons.Default.Login else Icons.Default.Logout, null) }
                    )
                }
            }
        }
    }
    if (confirmClear) AlertDialog(onDismissRequest = { confirmClear = false }, title = { Text("Limpiar historial") }, text = { Text("¿Deseas eliminar todos los registros guardados en este dispositivo?") }, confirmButton = { TextButton(onClick = { repository.clear(); records = emptyList(); confirmClear = false }) { Text("Eliminar") } }, dismissButton = { TextButton(onClick = { confirmClear = false }) { Text("Cancelar") } })
}
