package com.gamarra.carnetvirtual.data.local

import android.content.Context
import android.content.SharedPreferences

class SessionManager(
    context: Context
) {

    private val preferences: SharedPreferences =
        context.getSharedPreferences(
            "CARNET_VIRTUAL_SESSION",
            Context.MODE_PRIVATE
        )

    companion object {
        private const val KEY_DNI = "DNI_USUARIO"
        private const val KEY_LOGGED_IN = "LOGGED_IN"
        private const val KEY_USUARIO = "USUARIO"
        private const val KEY_ID_CARNET = "ID_CARNET_USUARIO"
        private const val KEY_NOMBRE = "NOMBRE_USUARIO"
        private const val KEY_CARGO = "CARGO_USUARIO"
        private const val KEY_CODIGO = "CODIGO_USUARIO"
    }

    /*
     * Login de prueba anterior.
     * Se mantiene para no romper otras partes del proyecto.
     */
    fun login(
        usuario: String,
        clave: String
    ): Boolean {

        val credencialesCorrectas =
            usuario.trim().equals("admin", ignoreCase = true) &&
                    clave == "admin123"

        if (credencialesCorrectas) {
            preferences.edit()
                .putBoolean(KEY_LOGGED_IN, true)
                .putString(KEY_USUARIO, usuario.trim())
                .apply()
        }

        return credencialesCorrectas
    }

    /*
     * Guarda los datos del carnet real encontrado durante el login.
     */
    fun guardarDatosUsuario(
        idCarnet: String,
        nombreCompleto: String,
        cargo: String,
        codigo: String,
        dni: String
    ) {
        preferences.edit()
            .putBoolean(KEY_LOGGED_IN, true)
            .putString(KEY_ID_CARNET, idCarnet)
            .putString(KEY_NOMBRE, nombreCompleto)
            .putString(KEY_CARGO, cargo)
            .putString(KEY_CODIGO, codigo)
            .putString(KEY_DNI, dni)
            .apply()
    }
    fun obtenerDniUsuario(): String {
        return preferences.getString(
            KEY_DNI,
            ""
        ).orEmpty()
    }

    fun guardarCarnetId(idCarnet: String) {
        preferences.edit()
            .putString(KEY_ID_CARNET, idCarnet)
            .apply()
    }

    fun obtenerCarnetId(): String {
        return preferences.getString(
            KEY_ID_CARNET,
            ""
        ).orEmpty()
    }

    fun obtenerNombreUsuario(): String {
        return preferences.getString(
            KEY_NOMBRE,
            ""
        ).orEmpty()
    }

    fun obtenerCargoUsuario(): String {
        return preferences.getString(
            KEY_CARGO,
            ""
        ).orEmpty()
    }

    fun obtenerCodigoUsuario(): String {
        return preferences.getString(
            KEY_CODIGO,
            ""
        ).orEmpty()
    }

    fun isLoggedIn(): Boolean {
        return preferences.getBoolean(
            KEY_LOGGED_IN,
            false
        )
    }

    fun logout() {
        preferences.edit()
            .clear()
            .apply()
    }

    fun cerrarSesion() {
        logout()
    }
}