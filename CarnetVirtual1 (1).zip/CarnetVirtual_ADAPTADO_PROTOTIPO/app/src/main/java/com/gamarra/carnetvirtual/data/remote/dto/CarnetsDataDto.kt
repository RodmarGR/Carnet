package com.gamarra.carnetvirtual.data.remote.dto

data class CarnetsDataDto(
    val items: List<CarnetDto>,
    val nextKey: String?
)