package com.gamarra.carnetvirtual.presentation.event

import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.asSharedFlow

object EventBus {

    private val _events = MutableSharedFlow<UiEvent>()

    val events = _events.asSharedFlow()

    suspend fun send(event: UiEvent) {
        _events.emit(event)
    }
}