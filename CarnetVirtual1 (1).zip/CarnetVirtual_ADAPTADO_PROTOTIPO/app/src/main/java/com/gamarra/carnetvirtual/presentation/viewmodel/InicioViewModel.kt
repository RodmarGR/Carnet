package com.gamarra.carnetvirtual.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.gamarra.carnetvirtual.domain.model.Carnet
import com.gamarra.carnetvirtual.domain.usecase.CarnetUseCases
import com.gamarra.carnetvirtual.presentation.event.EventBus
import com.gamarra.carnetvirtual.presentation.event.UiEvent
import com.gamarra.carnetvirtual.presentation.screens.inicio.InicioUiState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class InicioViewModel(
    private val useCases: CarnetUseCases,
) : ViewModel() {

    private val _uiState = MutableStateFlow(InicioUiState())
    val uiState = _uiState.asStateFlow()

    private var carnets = listOf<Carnet>()

    init {
        cargarCarnets()
    }

    fun cargarCarnets() {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)

            try {
                carnets = useCases.getCarnets()

                _uiState.value = _uiState.value.copy(
                    listaCarnets = carnets,
                    isLoading = false,
                    search = "",
                    listaCarnetsFiltro = emptyList()
                )

            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = e.message
                )

                EventBus.send(
                    UiEvent.Error("Error al listar carnets: ${e.message}")
                )
            }
        }
    }

    fun setEliminar(estado: Boolean) {
        _uiState.value = _uiState.value.copy(isDelete = estado)
    }

    fun eliminarCarnet(id: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isLoading = true)

            try {
                useCases.eliminarCarnet(id)

                EventBus.send(
                    UiEvent.Success("Carnet eliminado")
                )

                _uiState.value = _uiState.value.copy(isLoading = false)

                cargarCarnets()

            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    error = e.message
                )

                EventBus.send(
                    UiEvent.Error("Error al eliminar carnet: ${e.message}")
                )
            }
        }
    }

    fun onSearchChange(value: String) {
        _uiState.update {
            it.copy(search = value)
        }

        val filtered = carnets.filter {
            "${it.nombres} ${it.apellidos} ${it.dni} ${it.codigo}"
                .contains(value, ignoreCase = true)
        }

        _uiState.update {
            it.copy(listaCarnetsFiltro = filtered)
        }
    }
}