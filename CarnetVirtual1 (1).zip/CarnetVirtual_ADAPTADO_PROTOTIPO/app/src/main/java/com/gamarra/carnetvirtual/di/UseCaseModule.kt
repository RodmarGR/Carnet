package com.gamarra.carnetvirtual.di

import com.gamarra.carnetvirtual.domain.usecase.ActualizarCarnetUseCase
import com.gamarra.carnetvirtual.domain.usecase.CarnetUseCases
import com.gamarra.carnetvirtual.domain.usecase.EliminarCarnetUseCase
import com.gamarra.carnetvirtual.domain.usecase.GetCarnetUseCase
import com.gamarra.carnetvirtual.domain.usecase.GetCarnetsUseCase
import com.gamarra.carnetvirtual.domain.usecase.InsertarCarnetUseCase
import com.gamarra.carnetvirtual.domain.usecase.LoginUseCase

class UseCaseModule(repositoryModule: RepositoryModule) {

    val carnetUseCases by lazy {
        CarnetUseCases(
            getCarnets = GetCarnetsUseCase(repositoryModule.carnetRepository),
            login = LoginUseCase(repositoryModule.carnetRepository),
            insertarCarnet = InsertarCarnetUseCase(repositoryModule.carnetRepository),
            getCarnet = GetCarnetUseCase(repositoryModule.carnetRepository),
            actualizarCarnet = ActualizarCarnetUseCase(repositoryModule.carnetRepository),
            eliminarCarnet = EliminarCarnetUseCase(repositoryModule.carnetRepository)
        )
    }

}