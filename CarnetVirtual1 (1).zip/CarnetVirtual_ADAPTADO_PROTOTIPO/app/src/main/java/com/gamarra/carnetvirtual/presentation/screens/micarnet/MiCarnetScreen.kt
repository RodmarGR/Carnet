package com.gamarra.carnetvirtual.presentation.screens.micarnet

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.QrCode2
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.gamarra.carnetvirtual.di.AppContainer
import com.gamarra.carnetvirtual.presentation.components.EmptyScreen
import com.gamarra.carnetvirtual.presentation.components.LoadingScreen

@Composable
fun MiCarnetScreen(container: AppContainer) {
    val state by container.inicioViewModel.uiState.collectAsState()
    var index by remember { mutableIntStateOf(0) }
    if (state.isLoading) return LoadingScreen()
    if (state.listaCarnets.isEmpty()) return EmptyScreen("No hay carnets para mostrar")
    val carnet = state.listaCarnets[index.coerceIn(0, state.listaCarnets.lastIndex)]

    val context = LocalContext.current
    val imageName = "${carnet.nombres.split(" ")[0]}_${carnet.apellidos.split(" ")[0]}".lowercase()
    val imageRes = remember(imageName) {
        val id = context.resources.getIdentifier(imageName, "drawable", context.packageName)
        if (id != 0) id else 0
    }

    Column(Modifier.fillMaxSize().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        Card(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), elevation = CardDefaults.cardElevation(10.dp)) {
            Column(
                Modifier.background(Brush.verticalGradient(listOf(Color(0xFFE91E63), Color(0xFF8E1747)))).padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text("CARNET VIRTUAL", color = Color.White, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(16.dp))
                if (imageRes != 0) {
                    Image(
                        painter = painterResource(id = imageRes),
                        contentDescription = null,
                        modifier = Modifier
                            .size(100.dp)
                            .clip(CircleShape),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Icon(Icons.Default.AccountCircle, null, Modifier.size(100.dp), tint = Color.White)
                }
                Text("${carnet.nombres} ${carnet.apellidos}", color = Color.White, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(14.dp))
                Info("DNI", carnet.dni); Info("Código", carnet.codigo); Info("Cargo", carnet.cargo)
                Info("Empresa", carnet.empresa); Info("Sede", carnet.sede); Info("Estado", carnet.estado)
                Info("Vencimiento", carnet.fechaVencimiento)
                Spacer(Modifier.height(14.dp))
                Icon(Icons.Default.QrCode2, "Código QR referencial", Modifier.size(92.dp), tint = Color.White)
            }
        }
        if (state.listaCarnets.size > 1) {
            Spacer(Modifier.height(18.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                OutlinedButton(onClick = { if (index > 0) index-- }, enabled = index > 0) { Text("Anterior") }
                OutlinedButton(onClick = { if (index < state.listaCarnets.lastIndex) index++ }, enabled = index < state.listaCarnets.lastIndex) { Text("Siguiente") }
            }
            Text("Carnet ${index + 1} de ${state.listaCarnets.size}", modifier = Modifier.padding(top = 8.dp))
        }
    }
}

@Composable private fun Info(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, color = Color.White.copy(alpha = .8f)); Text(value.ifBlank { "-" }, color = Color.White, fontWeight = FontWeight.SemiBold)
    }
}
