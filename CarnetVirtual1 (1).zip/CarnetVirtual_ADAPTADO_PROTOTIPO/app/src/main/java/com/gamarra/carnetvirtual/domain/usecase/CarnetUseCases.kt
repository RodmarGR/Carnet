package com.gamarra.carnetvirtual.domain.usecase

data class CarnetUseCases(

    val getCarnets: GetCarnetsUseCase,

    val login: LoginUseCase,

    val insertarCarnet: InsertarCarnetUseCase,

    val getCarnet: GetCarnetUseCase,

    val actualizarCarnet: ActualizarCarnetUseCase,

    val eliminarCarnet: EliminarCarnetUseCase

)