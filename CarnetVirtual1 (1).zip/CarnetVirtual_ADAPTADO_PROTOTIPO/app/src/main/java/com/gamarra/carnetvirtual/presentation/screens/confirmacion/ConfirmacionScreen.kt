package com.gamarra.carnetvirtual.presentation.screens.confirmacion

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.gamarra.carnetvirtual.presentation.navigation.NavRutas

@Composable
fun ConfirmacionScreen(navController: NavHostController, tipo: String, fecha: String, hora: String) {
    Column(
        modifier = Modifier.fillMaxSize().padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Icon(Icons.Default.CheckCircle, null, Modifier.size(100.dp), tint = Color(0xFF2E9D4D))
        Spacer(Modifier.height(16.dp))
        Text("¡Registro exitoso!", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Tu acción fue registrada correctamente.")
        Spacer(Modifier.height(24.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Detalle("Tipo", tipo)
                Detalle("Fecha", fecha)
                Detalle("Hora", hora)
                Detalle("Sede", "Principal")
            }
        }
        Spacer(Modifier.height(24.dp))
        Button(
            onClick = { navController.navigate(NavRutas.HISTORIAL) { launchSingleTop = true } },
            modifier = Modifier.fillMaxWidth()
        ) { Text("VER HISTORIAL") }
        TextButton(onClick = { navController.navigate(NavRutas.INICIO) { launchSingleTop = true } }) {
            Text("VOLVER AL INICIO")
        }
    }
}

@Composable private fun Detalle(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label); Text(value, fontWeight = FontWeight.SemiBold)
    }
}
