package com.gamarra.carnetvirtual.presentation.screens.inicio

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.Button
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.gamarra.carnetvirtual.di.AppContainer
import com.gamarra.carnetvirtual.domain.model.Carnet
import com.gamarra.carnetvirtual.presentation.components.ConfirmarDialog
import com.gamarra.carnetvirtual.presentation.components.EmptyScreen
import com.gamarra.carnetvirtual.presentation.components.LoadingScreen
import com.gamarra.carnetvirtual.presentation.navigation.NavRutas

@Composable
fun InicioScreen(
    container: AppContainer,
    navHostController: NavHostController
) {

    val viewModel = container.inicioViewModel
    val uiState by viewModel.uiState.collectAsState()

    var selectedCarnet by remember {
        mutableStateOf<Carnet?>(null)
    }

    if (uiState.isLoading) {

        LoadingScreen()

    } else {

        if (uiState.listaCarnets.isEmpty()) {

            EmptyScreen("No existen carnets registrados")

        } else {

            Column(modifier = Modifier.fillMaxSize()) {
                Row(
                    modifier = Modifier.fillMaxWidth().padding(12.dp),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Button(
                        onClick = { navHostController.navigate(NavRutas.AGREGAR) },
                        modifier = Modifier.weight(1f)
                    ) { Text("Nuevo carnet") }
                    OutlinedButton(
                        onClick = { navHostController.navigate(NavRutas.BUSCAR) },
                        modifier = Modifier.weight(1f)
                    ) { Text("Buscar") }
                }
                LazyColumn(modifier = Modifier.fillMaxSize()) {

                items(
                    items = uiState.listaCarnets,
                    key = { it.id }
                ) { carnet ->

                    CarnetItem(

                        carnet = carnet,

                        onEdit = {
                            navHostController.navigate(
                                "${NavRutas.EDITAR}/${carnet.id}"
                            )
                        },

                        onDelete = {
                            selectedCarnet = carnet
                            viewModel.setEliminar(true)
                        }

                    )

                }

                }
            }

        }

    }

    if (uiState.isDelete) {

        ConfirmarDialog(

            titulo = "Eliminar Carnet",

            item = selectedCarnet?.nombres ?: "",

            onConfirm = {

                viewModel.eliminarCarnet(selectedCarnet!!.id)

                viewModel.setEliminar(false)

            },

            onDismiss = {

                viewModel.setEliminar(false)

            }

        )

    }

}