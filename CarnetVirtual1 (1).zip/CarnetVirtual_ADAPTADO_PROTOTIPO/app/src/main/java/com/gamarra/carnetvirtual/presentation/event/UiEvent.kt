package com.gamarra.carnetvirtual.presentation.event

sealed class UiEvent {

    data class Success(val message: String) : UiEvent()

    data class Error(val message: String) : UiEvent()

    data class Warning(val message: String) : UiEvent()
}