package com.gamarra.carnetvirtual.presentation.screens.agregar

data class AgregarUiState(
    val codigo: String = "",
    val dni: String = "",
    val nombres: String = "",
    val apellidos: String = "",
    val cargo: String = "",
    val empresa: String = "",
    val sede: String = "",
    val fechaVencimiento: String = "",
    val estado: String = "Activo",
    val isLoading: Boolean = false,
    val isSuccess: Boolean = false,
    val errorMessage: String? = null
)