package com.gamarra.carnetvirtual.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.gamarra.carnetvirtual.domain.model.Carnet
import com.gamarra.carnetvirtual.domain.usecase.CarnetUseCases
import com.gamarra.carnetvirtual.presentation.event.EventBus
import com.gamarra.carnetvirtual.presentation.event.UiEvent
import com.gamarra.carnetvirtual.presentation.screens.agregar.AgregarUiState
import java.util.UUID
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class AgregarViewModel(
    private val useCases: CarnetUseCases
) : ViewModel() {

    private val _uiState = MutableStateFlow(AgregarUiState())
    val uiState = _uiState.asStateFlow()

    fun onCodigoChange(valor: String) {
        _uiState.value = _uiState.value.copy(codigo = valor)
    }

    fun onDniChange(valor: String) {
        _uiState.value = _uiState.value.copy(dni = valor)
    }

    fun onNombresChange(valor: String) {
        _uiState.value = _uiState.value.copy(nombres = valor)
    }

    fun onApellidosChange(valor: String) {
        _uiState.value = _uiState.value.copy(apellidos = valor)
    }

    fun onCargoChange(valor: String) {
        _uiState.value = _uiState.value.copy(cargo = valor)
    }

    fun onEmpresaChange(valor: String) {
        _uiState.value = _uiState.value.copy(empresa = valor)
    }

    fun onSedeChange(valor: String) {
        _uiState.value = _uiState.value.copy(sede = valor)
    }

    fun onFechaVencimientoChange(valor: String) {
        _uiState.value = _uiState.value.copy(fechaVencimiento = valor)
    }

    fun onEstadoChange(valor: String) {
        _uiState.value = _uiState.value.copy(estado = valor)
    }

    fun guardarCarnet() {
        viewModelScope.launch {
            if (!validarFormulario()) {
                return@launch
            }

            try {
                _uiState.value = _uiState.value.copy(
                    isLoading = true,
                    errorMessage = null
                )

                val carnet = Carnet(
                    id = UUID.randomUUID().toString(),
                    codigo = _uiState.value.codigo.trim(),
                    dni = _uiState.value.dni.trim(),
                    nombres = _uiState.value.nombres.trim(),
                    apellidos = _uiState.value.apellidos.trim(),
                    cargo = _uiState.value.cargo.trim(),
                    empresa = _uiState.value.empresa.trim(),
                    sede = _uiState.value.sede.trim(),
                    fechaVencimiento = _uiState.value.fechaVencimiento.trim(),
                    estado = _uiState.value.estado
                )

                useCases.insertarCarnet(carnet)

                limpiarForm()

                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    isSuccess = true
                )

                EventBus.send(
                    UiEvent.Success("Carnet registrado correctamente")
                )
            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = e.message ?: "No se pudo registrar el carnet"
                )

                EventBus.send(
                    UiEvent.Error(
                        e.message ?: "No se pudo registrar el carnet"
                    )
                )
            }
        }
    }

    private fun limpiarForm() {
        _uiState.value = AgregarUiState(
            estado = "Activo"
        )
    }

    fun clearSuccess() {
        _uiState.value = _uiState.value.copy(isSuccess = false)
    }

    private suspend fun validarFormulario(): Boolean {
        when {
            _uiState.value.codigo.isBlank() -> {
                EventBus.send(UiEvent.Warning("Ingrese el código"))
                return false
            }

            _uiState.value.dni.isBlank() -> {
                EventBus.send(UiEvent.Warning("Ingrese el DNI"))
                return false
            }

            _uiState.value.nombres.isBlank() -> {
                EventBus.send(UiEvent.Warning("Ingrese los nombres"))
                return false
            }

            _uiState.value.apellidos.isBlank() -> {
                EventBus.send(UiEvent.Warning("Ingrese los apellidos"))
                return false
            }

            _uiState.value.cargo.isBlank() -> {
                EventBus.send(UiEvent.Warning("Ingrese el cargo"))
                return false
            }

            _uiState.value.empresa.isBlank() -> {
                EventBus.send(UiEvent.Warning("Ingrese la empresa"))
                return false
            }

            _uiState.value.sede.isBlank() -> {
                EventBus.send(UiEvent.Warning("Ingrese la sede"))
                return false
            }

            _uiState.value.fechaVencimiento.isBlank() -> {
                EventBus.send(
                    UiEvent.Warning("Ingrese la fecha de vencimiento")
                )
                return false
            }

            _uiState.value.estado.isBlank() -> {
                EventBus.send(UiEvent.Warning("Seleccione el estado"))
                return false
            }
        }

        return true
    }
}