package com.gamarra.carnetvirtual.core.network

import com.gamarra.carnetvirtual.data.remote.dto.LoginResponse
import retrofit2.Response
import retrofit2.http.GET
import retrofit2.http.Query

interface AuthApiService {
    @GET("usuarios")
    suspend fun login(
        @Query("email") correo: String,
        @Query("password") clave: String
    ): Response<LoginResponse>
}