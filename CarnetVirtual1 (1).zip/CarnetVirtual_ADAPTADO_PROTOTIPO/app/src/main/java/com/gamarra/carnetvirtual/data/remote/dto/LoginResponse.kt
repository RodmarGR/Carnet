package com.gamarra.carnetvirtual.data.remote.dto

import com.google.gson.annotations.SerializedName

data class LoginResponse(
    @SerializedName("success")
    val success: Boolean = false,
    
    @SerializedName("message")
    val message: String? = null,
    
    @SerializedName("data")
    val data: CarnetDto? = null,

    // Campos redundantes por si vienen en la raíz (común en algunas implementaciones de API Gateway)
    @SerializedName("id")
    val id: String? = null,
    
    @SerializedName("nombre")
    val nombre: String? = null,
    
    @SerializedName("ap_paterno")
    val apPaterno: String? = null,
    
    @SerializedName("ap_materno")
    val apMaterno: String? = null,
    
    @SerializedName("rol")
    val rol: String? = null,
    
    @SerializedName("dni")
    val dni: String? = null,
    
    @SerializedName("codigo")
    val codigo: String? = null
) {
    /**
     * Retorna el objeto de datos unificado, priorizando el campo 'data' 
     * pero extrayendo de la raíz si 'data' es nulo.
     */
    fun getUnifiedData(): CarnetDto? {
        if (data != null) return data
        
        // Si no hay 'data', construimos uno con lo que haya en la raíz
        if (nombre != null || apPaterno != null || id != null) {
            return CarnetDto(
                id = id,
                nombres = nombre,
                apellidos = apPaterno,
                apellidoMaterno = apMaterno,
                cargo = rol,
                dni = dni,
                codigo = codigo
            )
        }
        return null
    }
}