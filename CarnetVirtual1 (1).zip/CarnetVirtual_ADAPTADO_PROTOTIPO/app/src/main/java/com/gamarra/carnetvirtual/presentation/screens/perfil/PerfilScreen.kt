package com.gamarra.carnetvirtual.presentation.screens.perfil

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.gamarra.carnetvirtual.data.local.SessionManager
import com.gamarra.carnetvirtual.presentation.navigation.NavRutas

@Composable
fun PerfilScreen(
    navController: NavHostController,
    sessionManager: SessionManager
) {
    val nombre = sessionManager.obtenerNombreUsuario()
    val cargo = sessionManager.obtenerCargoUsuario()
    val codigo = sessionManager.obtenerCodigoUsuario()
    val idCarnet = sessionManager.obtenerCarnetId()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = Icons.Default.AccountCircle,
            contentDescription = "Perfil",
            modifier = Modifier.size(110.dp),
            tint = MaterialTheme.colorScheme.primary
        )

        Text(
            text = nombre.ifBlank { "Usuario" },
            style = MaterialTheme.typography.headlineSmall,
            fontWeight = FontWeight.Bold
        )

        Text(
            text = cargo.ifBlank { "Sin cargo registrado" },
            style = MaterialTheme.typography.bodyMedium
        )

        Spacer(
            modifier = Modifier.height(24.dp)
        )

        Card(
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                DatoPerfil(
                    titulo = "Nombre",
                    valor = nombre.ifBlank { "-" }
                )

                DatoPerfil(
                    titulo = "Cargo",
                    valor = cargo.ifBlank { "-" }
                )

                DatoPerfil(
                    titulo = "Código",
                    valor = codigo.ifBlank { "-" }
                )

                DatoPerfil(
                    titulo = "ID carnet",
                    valor = idCarnet.ifBlank { "-" }
                )

                DatoPerfil(
                    titulo = "Aplicación",
                    valor = "Carnet Virtual"
                )

                DatoPerfil(
                    titulo = "Estado",
                    valor = "Sesión activa"
                )
            }
        }

        Spacer(
            modifier = Modifier.weight(1f)
        )

        Button(
            onClick = {
                sessionManager.logout()

                navController.navigate(NavRutas.LOGIN) {
                    popUpTo(0) {
                        inclusive = true
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(54.dp)
        ) {
            Icon(
                imageVector = Icons.Default.Logout,
                contentDescription = null
            )

            Spacer(
                modifier = Modifier.width(8.dp)
            )

            Text(
                text = "CERRAR SESIÓN"
            )
        }
    }
}

@Composable
private fun DatoPerfil(
    titulo: String,
    valor: String
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = titulo,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )

        Text(
            text = valor,
            fontWeight = FontWeight.SemiBold
        )
    }
}