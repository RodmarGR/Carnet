package com.gamarra.carnetvirtual.presentation.navigation

object NavRutas {
    const val LOGIN = "login"
    const val INICIO = "inicio"
    const val AGREGAR = "agregar"
    const val EDITAR = "editar"
    const val BUSCAR = "buscar"
    const val MI_CARNET = "mi_carnet"
    const val REGISTRO = "registro"
    const val HISTORIAL = "historial"
    const val PERFIL = "perfil"
    const val CONFIRMACION = "confirmacion"

    fun getTitulo(ruta: String?): String = when {
        ruta == LOGIN -> "Iniciar sesión"
        ruta == INICIO -> "Carnet Virtual"
        ruta == AGREGAR -> "Nuevo Carnet"
        ruta?.startsWith(EDITAR) == true -> "Editar Carnet"
        ruta?.startsWith(BUSCAR) == true -> "Buscar Carnet"
        ruta == MI_CARNET -> "Mi Carnet"
        ruta == REGISTRO -> "Registrar Acceso"
        ruta == HISTORIAL -> "Historial"
        ruta == PERFIL -> "Perfil"
        ruta?.startsWith(CONFIRMACION) == true -> "Confirmación"
        else -> "Carnet Virtual"
    }
}
