package com.gamarra.carnetvirtual.domain.model

data class Carnet(
    val id: String,
    val nombres: String,
    val apellidos: String,
    val dni: String,
    val codigo: String,
    val cargo: String,
    val empresa: String,
    val sede: String,
    val estado: String,
    val fechaVencimiento: String
)