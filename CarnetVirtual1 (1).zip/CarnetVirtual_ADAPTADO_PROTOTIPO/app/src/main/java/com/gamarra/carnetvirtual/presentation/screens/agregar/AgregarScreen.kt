package com.gamarra.carnetvirtual.presentation.screens.agregar

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Save
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import com.gamarra.carnetvirtual.di.AppContainer
import com.gamarra.carnetvirtual.presentation.components.FormCarnet

@Composable
fun AgregarScreen(
    container: AppContainer,
    navHostController: NavHostController
) {
    val viewModel = container.agregarViewModel
    val uiState by viewModel.uiState.collectAsState()

    LaunchedEffect(uiState.isSuccess) {
        if (uiState.isSuccess) {
            container.inicioViewModel.cargarCarnets()
            viewModel.clearSuccess()
            navHostController.popBackStack()
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        FormCarnet(
            codigo = uiState.codigo,
            dni = uiState.dni,
            nombres = uiState.nombres,
            apellidos = uiState.apellidos,
            cargo = uiState.cargo,
            empresa = uiState.empresa,
            sede = uiState.sede,
            fechaVencimiento = uiState.fechaVencimiento,
            estado = uiState.estado,
            onCodigoChange = viewModel::onCodigoChange,
            onDniChange = viewModel::onDniChange,
            onNombresChange = viewModel::onNombresChange,
            onApellidosChange = viewModel::onApellidosChange,
            onCargoChange = viewModel::onCargoChange,
            onEmpresaChange = viewModel::onEmpresaChange,
            onSedeChange = viewModel::onSedeChange,
            onFechaVencimientoChange = viewModel::onFechaVencimientoChange,
            onEstadoChange = viewModel::onEstadoChange
        )

        Spacer(modifier = Modifier.height(16.dp))

        Button(
            modifier = Modifier.fillMaxWidth(),
            onClick = {
                viewModel.guardarCarnet()
            },
            enabled = !uiState.isLoading,
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFFE91E63),
                contentColor = Color.White
            )
        ) {
            Icon(
                imageVector = Icons.Default.Save,
                contentDescription = "Guardar carnet"
            )

            Spacer(modifier = Modifier.width(8.dp))

            Text(
                text = if (uiState.isLoading) {
                    "Guardando..."
                } else {
                    "Guardar Carnet"
                }
            )
        }
    }
}