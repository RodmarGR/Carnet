package com.gamarra.carnetvirtual.presentation.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.gamarra.carnetvirtual.domain.model.Carnet
import com.gamarra.carnetvirtual.domain.usecase.CarnetUseCases
import com.gamarra.carnetvirtual.presentation.event.EventBus
import com.gamarra.carnetvirtual.presentation.event.UiEvent
import com.gamarra.carnetvirtual.presentation.screens.editar.EditarUiState
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class EditarViewModel(
    private val useCases: CarnetUseCases
) : ViewModel() {

    private val _uiState = MutableStateFlow(EditarUiState())
    val uiState = _uiState.asStateFlow()

    fun buscarCarnet(id: String) {
        viewModelScope.launch {
            try {
                _uiState.value = _uiState.value.copy(isLoading = true)

                val carnet = useCases.getCarnet(id)

                _uiState.value = _uiState.value.copy(
                    id = carnet.id,
                    codigo = carnet.codigo,
                    dni = carnet.dni,
                    nombres = carnet.nombres,
                    apellidos = carnet.apellidos,
                    cargo = carnet.cargo,
                    empresa = carnet.empresa,
                    sede = carnet.sede,
                    fechaVencimiento = carnet.fechaVencimiento,
                    estado = carnet.estado,
                    isLoading = false
                )

            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = e.message
                )

                EventBus.send(
                    UiEvent.Error(e.message ?: "Error al cargar carnet")
                )
            }
        }
    }

    fun onCodigoChange(valor: String) {
        _uiState.value = _uiState.value.copy(codigo = valor)
    }

    fun onDniChange(valor: String) {
        _uiState.value = _uiState.value.copy(dni = valor)
    }

    fun onNombresChange(valor: String) {
        _uiState.value = _uiState.value.copy(nombres = valor)
    }

    fun onApellidosChange(valor: String) {
        _uiState.value = _uiState.value.copy(apellidos = valor)
    }

    fun onCargoChange(valor: String) {
        _uiState.value = _uiState.value.copy(cargo = valor)
    }

    fun onEmpresaChange(valor: String) {
        _uiState.value = _uiState.value.copy(empresa = valor)
    }

    fun onSedeChange(valor: String) {
        _uiState.value = _uiState.value.copy(sede = valor)
    }

    fun onFechaVencimientoChange(valor: String) {
        _uiState.value = _uiState.value.copy(fechaVencimiento = valor)
    }

    fun onEstadoChange(valor: String) {
        _uiState.value = _uiState.value.copy(estado = valor)
    }

    fun actualizarCarnet() {
        viewModelScope.launch {
            if (!validarFormulario()) {
                return@launch
            }

            try {
                _uiState.value = _uiState.value.copy(isLoading = true)

                val carnet = Carnet(
                    id = _uiState.value.id,
                    codigo = _uiState.value.codigo,
                    dni = _uiState.value.dni,
                    nombres = _uiState.value.nombres,
                    apellidos = _uiState.value.apellidos,
                    cargo = _uiState.value.cargo,
                    empresa = _uiState.value.empresa,
                    sede = _uiState.value.sede,
                    fechaVencimiento = _uiState.value.fechaVencimiento,
                    estado = _uiState.value.estado
                )

                useCases.actualizarCarnet(carnet)

                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    isSuccess = true
                )

                EventBus.send(
                    UiEvent.Success("Carnet actualizado correctamente")
                )

            } catch (e: Exception) {
                _uiState.value = _uiState.value.copy(
                    isLoading = false,
                    errorMessage = e.message
                )
            }
        }
    }

    fun clearSuccess() {
        _uiState.value = _uiState.value.copy(isSuccess = false)
    }

    private suspend fun validarFormulario(): Boolean {
        when {
            _uiState.value.codigo.isBlank() -> {
                EventBus.send(UiEvent.Warning("Ingrese el código"))
                return false
            }

            _uiState.value.dni.isBlank() -> {
                EventBus.send(UiEvent.Warning("Ingrese el DNI"))
                return false
            }

            _uiState.value.nombres.isBlank() -> {
                EventBus.send(UiEvent.Warning("Ingrese los nombres"))
                return false
            }

            _uiState.value.apellidos.isBlank() -> {
                EventBus.send(UiEvent.Warning("Ingrese los apellidos"))
                return false
            }

            _uiState.value.cargo.isBlank() -> {
                EventBus.send(UiEvent.Warning("Ingrese el cargo"))
                return false
            }

            _uiState.value.empresa.isBlank() -> {
                EventBus.send(UiEvent.Warning("Ingrese la empresa"))
                return false
            }

            _uiState.value.sede.isBlank() -> {
                EventBus.send(UiEvent.Warning("Ingrese la sede"))
                return false
            }

            _uiState.value.fechaVencimiento.isBlank() -> {
                EventBus.send(UiEvent.Warning("Ingrese la fecha de vencimiento"))
                return false
            }
        }

        return true
    }
}