package com.gamarra.carnetvirtual.data.repository

import com.gamarra.carnetvirtual.data.mapper.CarnetMapper
import com.gamarra.carnetvirtual.data.remote.datasource.RemoteDataSource
import com.gamarra.carnetvirtual.domain.model.Carnet
import com.gamarra.carnetvirtual.domain.repository.CarnetRepository

class CarnetRepositoryImpl(
    private val remoteDataSource: RemoteDataSource
) : CarnetRepository {

    override suspend fun getCarnets(): List<Carnet> {
        return remoteDataSource.getCarnets()?.data?.items?.map {
            CarnetMapper.toDomain(it)
        } ?: emptyList()
    }

    override suspend fun login(correo: String, clave: String): Carnet {
        val response = remoteDataSource.login(correo, clave)
        val userData = response?.getUnifiedData()
        
        if (userData != null) {
            return CarnetMapper.toDomain(userData)
        } else {
            throw Exception(response?.message ?: "Error al iniciar sesión: Usuario no encontrado")
        }
    }

    override suspend fun insertarCarnet(carnet: Carnet) {
        remoteDataSource.insertarCarnet(
            CarnetMapper.toInsertCarnetRequest(carnet)
        )
    }

    override suspend fun getCarnetById(id: String): Carnet {
        return remoteDataSource.getCarnetById(id)?.let {
            CarnetMapper.toDomain(it)
        } ?: throw Exception("Carnet no encontrado")
    }

    override suspend fun actualizarCarnet(carnet: Carnet) {
        remoteDataSource.actualizarCarnet(
            carnet.id,
            CarnetMapper.toInsertCarnetRequest(carnet)
        )
    }

    override suspend fun eliminarCarnet(id: String) {
        remoteDataSource.eliminarCarnet(id)
    }
}