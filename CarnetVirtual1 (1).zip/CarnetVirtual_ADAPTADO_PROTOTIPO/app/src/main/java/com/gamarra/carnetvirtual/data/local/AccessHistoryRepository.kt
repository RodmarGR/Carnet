package com.gamarra.carnetvirtual.data.local

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class AccessRecord(
    val id: String,
    val tipo: String,
    val fecha: String,
    val hora: String,
    val timestamp: Long
)

class AccessHistoryRepository(context: Context) {
    private val prefs = context.getSharedPreferences("access_history", Context.MODE_PRIVATE)

    fun register(tipo: String): AccessRecord {
        val now = Date()
        val record = AccessRecord(
            id = UUID.randomUUID().toString(),
            tipo = tipo,
            fecha = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(now),
            hora = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(now),
            timestamp = now.time
        )
        val current = getAll().toMutableList().apply { add(0, record) }
        save(current)
        return record
    }

    fun getAll(): List<AccessRecord> {
        val raw = prefs.getString(KEY_RECORDS, "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val item = array.getJSONObject(i)
                    add(
                        AccessRecord(
                            id = item.getString("id"),
                            tipo = item.getString("tipo"),
                            fecha = item.getString("fecha"),
                            hora = item.getString("hora"),
                            timestamp = item.getLong("timestamp")
                        )
                    )
                }
            }.sortedByDescending { it.timestamp }
        }.getOrDefault(emptyList())
    }

    fun clear() = prefs.edit().remove(KEY_RECORDS).apply()

    private fun save(records: List<AccessRecord>) {
        val array = JSONArray()
        records.forEach { record ->
            array.put(JSONObject().apply {
                put("id", record.id)
                put("tipo", record.tipo)
                put("fecha", record.fecha)
                put("hora", record.hora)
                put("timestamp", record.timestamp)
            })
        }
        prefs.edit().putString(KEY_RECORDS, array.toString()).apply()
    }

    companion object { private const val KEY_RECORDS = "records" }
}
