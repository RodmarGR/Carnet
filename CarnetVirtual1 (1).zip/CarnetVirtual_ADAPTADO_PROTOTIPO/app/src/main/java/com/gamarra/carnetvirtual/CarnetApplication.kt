package com.gamarra.carnetvirtual

import android.app.Application
import com.gamarra.carnetvirtual.di.AppContainer

class CarnetApplication : Application() {

    lateinit var container: AppContainer

    override fun onCreate() {
        super.onCreate()
        container = AppContainer()
    }
}