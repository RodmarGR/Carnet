package com.gamarra.carnetvirtual.presentation.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ExitToApp
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.gamarra.carnetvirtual.data.local.SessionManager
import com.gamarra.carnetvirtual.presentation.navigation.NavRutas

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppTopBar(
    navHostController: NavHostController,
    sessionManager: SessionManager? = null
) {

    var menuAbierto by remember {
        mutableStateOf(false)
    }

    val context = LocalContext.current
    val imageRes = remember(sessionManager) {
        val nombre = sessionManager?.obtenerNombreUsuario().orEmpty()
        val parts = nombre.split(" ")
        if (parts.size >= 2) {
            val fileName = "${parts[0]}_${parts[1]}".lowercase()
            context.resources.getIdentifier(fileName, "drawable", context.packageName)
        } else 0
    }

    val rutaActual = navHostController
        .currentBackStackEntryAsState()
        .value
        ?.destination
        ?.route

    val puedeRegresar =
        rutaActual != NavRutas.INICIO &&
                rutaActual != NavRutas.LOGIN

    CenterAlignedTopAppBar(

        title = {
            Text(
                text = NavRutas.getTitulo(rutaActual)
            )
        },

        navigationIcon = {

            if (puedeRegresar) {

                IconButton(
                    onClick = {
                        navHostController.popBackStack()
                    }
                ) {

                    Icon(
                        imageVector = Icons.Default.ArrowBack,
                        contentDescription = "Regresar"
                    )
                }
            }
        },

        actions = {

            IconButton(
                onClick = {
                    menuAbierto = true
                }
            ) {
                if (imageRes != 0) {
                    Image(
                        painter = painterResource(id = imageRes),
                        contentDescription = "Usuario",
                        modifier = Modifier
                            .size(32.dp)
                            .clip(CircleShape),
                        contentScale = ContentScale.Crop
                    )
                } else {
                    Icon(
                        imageVector = Icons.Default.AccountCircle,
                        contentDescription = "Usuario"
                    )
                }
            }

            DropdownMenu(
                expanded = menuAbierto,
                onDismissRequest = {
                    menuAbierto = false
                }
            ) {

                DropdownMenuItem(

                    text = {
                        Text(
                            text = "Cerrar sesión"
                        )
                    },

                    leadingIcon = {

                        Icon(
                            imageVector = Icons.Default.ExitToApp,
                            contentDescription = null
                        )
                    },

                    onClick = {

                        menuAbierto = false

                        navHostController.navigate(
                            NavRutas.LOGIN
                        ) {

                            popUpTo(0) {
                                inclusive = true
                            }

                            launchSingleTop = true
                        }
                    }
                )
            }
        }
    )
}