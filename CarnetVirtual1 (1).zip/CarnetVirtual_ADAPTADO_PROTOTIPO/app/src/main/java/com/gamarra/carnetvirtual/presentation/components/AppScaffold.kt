package com.gamarra.carnetvirtual.presentation.components

import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Icon
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Snackbar
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.gamarra.carnetvirtual.data.local.SessionManager
import com.gamarra.carnetvirtual.presentation.event.EventBus
import com.gamarra.carnetvirtual.presentation.event.UiEvent
import com.gamarra.carnetvirtual.presentation.navigation.NavRutas

@Composable
fun AppScaffold(
    navHostController: NavHostController,
    sessionManager: SessionManager? = null,
    content: @Composable (PaddingValues) -> Unit
) {
    val snackbarHostState = remember {
        SnackbarHostState()
    }

    val rutaActual = navHostController
        .currentBackStackEntryAsState()
        .value
        ?.destination
        ?.route

    val esLogin = rutaActual == NavRutas.LOGIN || rutaActual == null

    LaunchedEffect(Unit) {
        EventBus.events.collect { event ->

            val snackbarCustom = when (event) {

                is UiEvent.Success -> SnackbarCustom(
                    message = event.message,
                    status = SnackbarStatus.SUCCESS
                )

                is UiEvent.Error -> SnackbarCustom(
                    message = event.message,
                    status = SnackbarStatus.ERROR
                )

                is UiEvent.Warning -> SnackbarCustom(
                    message = event.message,
                    status = SnackbarStatus.WARNING
                )
            }

            snackbarHostState.showSnackbar(snackbarCustom)
        }
    }

    Scaffold(
        bottomBar = {
            if (!esLogin) {
                AppBottomBar(navHostController)
            }
        },

        topBar = {
            if (!esLogin) {
                AppTopBar(navHostController, sessionManager)
            }
        },

        snackbarHost = {
            SnackbarHost(
                hostState = snackbarHostState
            ) { snackbarData ->

                val snackbarCustom =
                    snackbarData.visuals as? SnackbarCustom

                if (snackbarCustom != null) {

                    val estado = snackbarCustom.status

                    Snackbar(
                        containerColor = estado.colorFondo,
                        contentColor = estado.colorTexto,
                        modifier = Modifier.padding(12.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = estado.icono,
                                contentDescription = null,
                                tint = estado.colorTexto
                            )

                            Spacer(
                                modifier = Modifier.width(12.dp)
                            )

                            Text(
                                text = snackbarCustom.message
                            )
                        }
                    }

                } else {
                    Snackbar(
                        snackbarData = snackbarData
                    )
                }
            }
        }
    ) { paddingValues ->

        content(paddingValues)
    }
}